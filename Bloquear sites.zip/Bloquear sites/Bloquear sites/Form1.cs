﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Bloquear_sites
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string site = textBox1.Text.Trim();

            if (!string.IsNullOrEmpty(site))
            {
                try
                {
                    // Caminho para o arquivo "hosts"
                    string hostsPath = Path.Combine(Environment.SystemDirectory, @"drivers\etc\hosts");

                    // Adiciona as três versões do site ao arquivo "hosts"
                    using (StreamWriter sw = File.AppendText(hostsPath))
                    {
                        sw.WriteLine("127.0.0.1\thttps://" + site);
                        sw.WriteLine("127.0.0.1\thttp://" + site);
                        sw.WriteLine("127.0.0.1\t" + site);
                    }

                    // Limpa o cache DNS do sistema operacional
                    FlushDNS();

                    // Limpa o cache DNS do Google Chrome
                    ClearChromeDNS();

                    // Limpa o cache DNS do Firefox
                    ClearFirefoxDNS();

                    MessageBox.Show("O site '" + site + "' foi bloqueado com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro ao bloquear o site: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Insira um site válido!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void FlushDNS()
        {
            try
            {
                System.Diagnostics.Process.Start("ipconfig", "/flushdns");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao limpar o cache DNS do sistema operacional: " + ex.Message);
            }
        }

        private void ClearChromeDNS()
        {
            try
            {
                System.Diagnostics.Process.Start("chrome.exe", "chrome://net-internals/#dns");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao limpar o cache DNS do Google Chrome: " + ex.Message);
            }
        }

        private void ClearFirefoxDNS()
        {
            try
            {
                System.Diagnostics.Process.Start("firefox.exe", "about:config");
                System.Diagnostics.Process.Start("firefox.exe", "about:preferences#privacy");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao limpar o cache DNS do Firefox: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string site = textBox2.Text.Trim();

            if (!string.IsNullOrEmpty(site))
            {
                try
                {
                    // Caminho para o arquivo "hosts"
                    string hostsPath = Path.Combine(Environment.SystemDirectory, @"drivers\etc\hosts");

                    // Lê todas as linhas do arquivo "hosts"
                    string[] lines = File.ReadAllLines(hostsPath);

                    // Cria uma nova lista de linhas do arquivo "hosts" sem as entradas do site a ser desbloqueado
                    var updatedLines = new System.Collections.Generic.List<string>();

                    foreach (string line in lines)
                    {
                        // Verifica se a linha contém o site a ser desbloqueado
                        if (!line.Contains(site))
                        {
                            updatedLines.Add(line);
                        }
                    }

                    // Escreve as linhas atualizadas no arquivo "hosts"
                    File.WriteAllLines(hostsPath, updatedLines);

                    // Limpa o cache DNS do sistema operacional
                    FlushDNS();

                    // Limpa o cache DNS do Google Chrome
                    ClearChromeDNS();

                    // Limpa o cache DNS do Firefox
                    ClearFirefoxDNS();

                    MessageBox.Show("O site '" + site + "' foi desbloqueado com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro ao desbloquear o site: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Insira um site válido!");
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}

